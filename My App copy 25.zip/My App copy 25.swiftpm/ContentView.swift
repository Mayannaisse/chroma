import SwiftUI
import UIKit

// MARK: - Models

struct PaletteEntry: Identifiable {
    let id = UUID()
    let mode: String
    let colors: [ColorSwatch]
}

struct ColorSwatch: Identifiable {
    let id = UUID()
    let hue: Double
    let saturation: Double
    let lightness: Double
    let label: String
    
    var color: Color {
        Color(hue: hue / 360, saturation: saturation, brightness: lightnessToSB)
    }
    
    var hex: String { hslToHex(h: hue, s: saturation, l: lightness) }
    
    var lightnessToSB: Double {
        // Convert HSL lightness to SwiftUI HSB brightness
        let l = lightness / 100
        let s = saturation
        let b = l + s * min(l, 1 - l)
        return b
    }
    
    var saturationHSB: Double {
        let l = lightness / 100
        let s = saturation
        let b = l + s * min(l, 1 - l)
        return b == 0 ? 0 : 2 * (1 - l / b)
    }
    
    var uiColor: UIColor {
        UIColor(hue: CGFloat(hue / 360),
                saturation: CGFloat(saturationHSB),
                brightness: CGFloat(lightnessToSB),
                alpha: 1)
    }
}

struct ComboPreset: Identifiable {
    let id = UUID()
    let name: String
    let desc: String
    let hues: [Double]
}

struct PantoneMatch {
    let name: String
    let number: String
    let hex: String
    let matchPct: Int
}

// MARK: - Color Math

func hslToHex(h: Double, s: Double, l: Double) -> String {
    let (r, g, b) = hslToRGB(h: h, s: s, l: l / 100)
    let ri = Int(r * 255)
    let gi = Int(g * 255)
    let bi = Int(b * 255)
    return String(format: "#%02X%02X%02X", ri, gi, bi)
}

func hslToRGB(h: Double, s: Double, l: Double) -> (Double, Double, Double) {
    if s == 0 { return (l, l, l) }
    let q = l < 0.5 ? l * (1 + s) : l + s - l * s
    let p = 2 * l - q
    func hue2rgb(_ t: Double) -> Double {
        var t = t
        if t < 0 { t += 1 }
        if t > 1 { t -= 1 }
        if t < 1/6 { return p + (q - p) * 6 * t }
        if t < 1/2 { return q }
        if t < 2/3 { return p + (q - p) * (2/3 - t) * 6 }
        return p
    }
    return (hue2rgb(h/360 + 1/3), hue2rgb(h/360), hue2rgb(h/360 - 1/3))
}

func hexToRGB(_ hex: String) -> (Double, Double, Double) {
    let h = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
    let r = Double(Int(h.prefix(2), radix: 16) ?? 0) / 255
    let g = Double(Int(h.dropFirst(2).prefix(2), radix: 16) ?? 0) / 255
    let b = Double(Int(h.dropFirst(4).prefix(2), radix: 16) ?? 0) / 255
    return (r, g, b)
}

func colorDistance(_ hex1: String, _ hex2: String) -> Double {
    let (r1, g1, b1) = hexToRGB(hex1)
    let (r2, g2, b2) = hexToRGB(hex2)
    return sqrt(pow((r1-r2)*255, 2) + pow((g1-g2)*255, 2) + pow((b1-b2)*255, 2))
}

func closestPantone(hex: String) -> PantoneMatch {
    var best = pantoneDB[0]
    var bestDist = colorDistance(hex, pantoneDB[0].hex)
    for entry in pantoneDB.dropFirst() {
        let d = colorDistance(hex, entry.hex)
        if d < bestDist { bestDist = d; best = entry }
    }
    let pct = max(0, Int((1 - bestDist / 441) * 100))
    return PantoneMatch(name: best.name, number: best.num, hex: best.hex, matchPct: pct)
}

func harmonyHues(base: Double, mode: String) -> [(hue: Double, label: String)] {
    switch mode {
    case "complementary": return [(hue: (base + 180).truncatingRemainder(dividingBy: 360), label: "Comp")]
    case "analogous": return [
        (hue: (base + 30).truncatingRemainder(dividingBy: 360), label: "+30°"),
        (hue: (base - 30 + 360).truncatingRemainder(dividingBy: 360), label: "-30°")
    ]
    case "triadic": return [
        (hue: (base + 120).truncatingRemainder(dividingBy: 360), label: "+120°"),
        (hue: (base + 240).truncatingRemainder(dividingBy: 360), label: "+240°")
    ]
    default: return []
    }
}

// MARK: - Color Wheel View (Canvas-based)

struct ColorWheelView: View {
    let size: CGFloat
    let lightness: Double
    let isDark: Bool
    @Binding var primaryHue: Double
    @Binding var primarySat: Double
    let mode: String
    
    private var radius: CGFloat { size / 2 - 8 }
    private var center: CGPoint { CGPoint(x: size / 2, y: size / 2) }
    
    private func dotPosition(hue: Double, sat: Double) -> CGPoint {
        let angle = hue * .pi / 180
        return CGPoint(
            x: center.x + cos(angle) * sat * radius,
            y: center.y + sin(angle) * sat * radius
        )
    }
    
    var body: some View {
        ZStack {
            Canvas { ctx, sz in
                let cx = sz.width / 2
                let cy = sz.height / 2
                let r = min(cx, cy) - 8
                
                // Draw wheel pixel by pixel using a grid of small rects
                let step: CGFloat = 1.5
                var x: CGFloat = cx - r
                while x <= cx + r {
                    var y: CGFloat = cy - r
                    while y <= cy + r {
                        let dx = x - cx
                        let dy = y - cy
                        let dist = sqrt(dx*dx + dy*dy)
                        if dist <= r {
                            let hue = (atan2(dy, dx) * 180 / .pi + 360).truncatingRemainder(dividingBy: 360)
                            let sat = dist / r
                            let l = isDark ? 0.40 : 0.55
                            let (rv, gv, bv) = hslToRGB(h: hue, s: Double(sat), l: l)
                            let color = Color(red: rv, green: gv, blue: bv)
                            ctx.fill(Path(CGRect(x: x, y: y, width: step, height: step)), with: .color(color))
                        }
                        y += step
                    }
                    x += step
                }
                
                // Vignette ring
                let path = Path(ellipseIn: CGRect(x: cx-r, y: cy-r, width: r*2, height: r*2))
                ctx.stroke(path, with: .color(.black.opacity(0.12)), lineWidth: 12)
            }
            .frame(width: size, height: size)
            .clipShape(Circle())
            
            // Harmony dots
            ForEach(Array(allDots().enumerated()), id: \.offset) { idx, dot in
                DotView(
                    position: dotPosition(hue: dot.hue, sat: dot.sat),
                    color: dotColor(hue: dot.hue, sat: dot.sat),
                    label: dot.label,
                    isPrimary: idx == 0,
                    bgColor: isDark ? Color(hex: "#18171A") : Color(hex: "#F2EFE9")
                )
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { val in
                            if idx == 0 {
                                let dx = val.location.x - center.x
                                let dy = val.location.y - center.y
                                let dist = sqrt(dx*dx + dy*dy)
                                guard dist <= radius else { return }
                                primaryHue = (atan2(dy, dx) * 180 / .pi + 360).truncatingRemainder(dividingBy: 360)
                                primarySat = Double(dist / radius)
                            }
                        }
                )
            }
        }
        .frame(width: size, height: size)
    }
    
    func allDots() -> [(hue: Double, sat: Double, label: String)] {
        var result: [(hue: Double, sat: Double, label: String)] = [(hue: primaryHue, sat: primarySat, label: "Base")]
        for h in harmonyHues(base: primaryHue, mode: mode) {
            result.append((hue: h.hue, sat: primarySat, label: h.label))
        }
        return result
    }
    
    func dotColor(hue: Double, sat: Double) -> Color {
        let (r, g, b) = hslToRGB(h: hue, s: sat, l: lightness / 100)
        return Color(red: r, green: g, blue: b)
    }
}

struct DotView: View {
    let position: CGPoint
    let color: Color
    let label: String
    let isPrimary: Bool
    let bgColor: Color
    
    var body: some View {
        ZStack {
            // Label
            Text(label)
                .font(.system(size: 9, design: .monospaced))
                .padding(.horizontal, 5)
                .padding(.vertical, 2)
                .background(bgColor)
                .foregroundColor(.primary)
                .cornerRadius(4)
                .opacity(0.85)
                .offset(x: 14, y: -14)
            
            // Dot
            Circle()
                .fill(color)
                .frame(width: isPrimary ? 22 : 18, height: isPrimary ? 22 : 18)
                .overlay(Circle().stroke(bgColor, lineWidth: 2.5))
                .shadow(color: .black.opacity(0.25), radius: 4, x: 0, y: 2)
        }
        .position(position)
    }
}

// MARK: - Pantone Panel

struct PantonePanel: View {
    let swatches: [ColorSwatch]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Closest Pantone Matches")
                .font(.system(size: 10, weight: .medium))
                .tracking(1.3)
                .textCase(.uppercase)
                .foregroundColor(Color(hex: "#7880A0"))
            
            ForEach(swatches) { swatch in
                let match = closestPantone(hex: swatch.hex)
                HStack(spacing: 9) {
                    RoundedRectangle(cornerRadius: 7)
                        .fill(Color(hex: match.hex))
                        .frame(width: 30, height: 30)
                        .overlay(RoundedRectangle(cornerRadius: 7).stroke(Color.black.opacity(0.07), lineWidth: 1))
                    
                    VStack(alignment: .leading, spacing: 2) {
                        Text(match.name)
                            .font(.system(size: 11, weight: .medium))
                            .foregroundColor(Color(hex: "#2B3145"))
                            .lineLimit(1)
                        Text("PMS \(match.number)")
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundColor(Color(hex: "#7880A0"))
                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                RoundedRectangle(cornerRadius: 2)
                                    .fill(Color(hex: "#E8E4DC"))
                                    .frame(height: 3)
                                RoundedRectangle(cornerRadius: 2)
                                    .fill(swatch.color)
                                    .frame(width: geo.size.width * CGFloat(match.matchPct) / 100, height: 3)
                            }
                        }
                        .frame(height: 3)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing, spacing: 2) {
                        Text(swatch.label)
                            .font(.system(size: 9))
                            .textCase(.uppercase)
                            .tracking(0.6)
                            .foregroundColor(Color(hex: "#7880A0"))
                        Text("\(match.matchPct)%")
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundColor(Color(hex: "#7880A0"))
                    }
                }
            }
        }
        .padding(13)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.black.opacity(0.09), lineWidth: 1))
    }
}

// MARK: - Swatch Strip

struct SwatchStrip: View {
    let swatches: [ColorSwatch]
    let onCopy: (String) -> Void
    
    var body: some View {
        HStack(spacing: 8) {
            ForEach(swatches) { swatch in
                VStack(spacing: 4) {
                    Circle()
                        .fill(swatch.color)
                        .frame(width: 36, height: 36)
                        .overlay(Circle().stroke(Color.black.opacity(0.07), lineWidth: 2))
                        .shadow(color: .black.opacity(0.12), radius: 4, x: 0, y: 2)
                    Text(swatch.hex)
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundColor(Color(hex: "#7880A0"))
                    Text(swatch.label)
                        .font(.system(size: 9))
                        .textCase(.uppercase)
                        .tracking(0.5)
                        .foregroundColor(Color(hex: "#7880A0"))
                }
                .onTapGesture { onCopy(swatch.hex) }
            }
        }
    }
}

// MARK: - Combo Card

struct ComboCard: View {
    let combo: ComboPreset
    let isActive: Bool
    let lightness: Double
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 3) {
                    ForEach(combo.hues, id: \.self) { h in
                        let (r, g, b) = hslToRGB(h: h, s: 0.72, l: 0.52)
                        Circle()
                            .fill(Color(red: r, green: g, blue: b))
                            .frame(width: 13, height: 13)
                            .overlay(Circle().stroke(Color.white.opacity(0.25), lineWidth: 1))
                    }
                }
                Text(combo.name)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(.white)
                Text(combo.desc)
                    .font(.system(size: 9))
                    .foregroundColor(.white.opacity(0.72))
            }
            .padding(7)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(hex: "#C9829A"))
            .cornerRadius(9)
            .overlay(
                RoundedRectangle(cornerRadius: 9)
                    .stroke(isActive ? Color(hex: "#8B3050").opacity(0.8) : Color(hex: "#8B3050").opacity(0.3), lineWidth: isActive ? 1.5 : 1)
            )
            .shadow(color: Color(hex: "#6E283C").opacity(0.22), radius: 2, x: 0, y: 2)
            .scaleEffect(isActive ? 0.97 : 1.0)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - History Item

struct HistoryItemView: View {
    let entry: PaletteEntry
    let onTap: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        HStack(spacing: 7) {
            HStack(spacing: 3) {
                ForEach(entry.colors) { c in
                    Circle()
                        .fill(c.color)
                        .frame(width: 11, height: 11)
                        .overlay(Circle().stroke(Color.white.opacity(0.2), lineWidth: 1))
                }
            }
            VStack(alignment: .leading, spacing: 1) {
                Text(entry.mode)
                    .font(.system(size: 9))
                    .textCase(.uppercase)
                    .tracking(0.8)
                    .foregroundColor(.white.opacity(0.65))
                Text(entry.colors.first?.hex ?? "")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundColor(.white)
            }
            Spacer()
            Button(action: onDelete) {
                Text("×")
                    .font(.system(size: 14))
                    .foregroundColor(.white.opacity(0.55))
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 6)
        .background(Color(hex: "#C9829A"))
        .cornerRadius(8)
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color(hex: "#8B3050").opacity(0.3), lineWidth: 1))
        .shadow(color: Color(hex: "#6E283C").opacity(0.2), radius: 2, x: 0, y: 2)
        .onTapGesture(perform: onTap)
    }
}

// MARK: - Mode Button

struct ModeButton: View {
    let title: String
    let isActive: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 12, weight: .medium))
                .tracking(0.3)
                .foregroundColor(isActive ? Color(hex: "#FFE8EE") : .white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(isActive ? Color(hex: "#8B3050") : Color(hex: "#C9829A"))
                .cornerRadius(12)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(isActive ? Color(hex: "#5A0F20").opacity(0.5) : Color(hex: "#8B3050").opacity(0.4), lineWidth: 1)
                )
                .shadow(color: Color(hex: "#6E283C").opacity(isActive ? 0.12 : 0.22), radius: isActive ? 1 : 3, x: 0, y: isActive ? 0 : 2)
                .scaleEffect(isActive ? 0.97 : 1.0)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Image Extractor

struct ImageExtractorView: View {
    @State private var showImagePicker = false
    @State private var extractedColors: [ExtractedColor] = []
    @State private var previewImage: UIImage? = nil
    let onCopy: (String) -> Void
    
    struct ExtractedColor: Identifiable {
        let id = UUID()
        let hex: String
        let pct: Int
        let pantone: PantoneMatch
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let img = previewImage {
                Image(uiImage: img)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity)
                    .frame(height: 100)
                    .clipped()
                    .cornerRadius(9)
                    .overlay(RoundedRectangle(cornerRadius: 9).stroke(Color.black.opacity(0.09), lineWidth: 1))
                
                ForEach(extractedColors) { c in
                    Button(action: { onCopy(c.hex) }) {
                        HStack(spacing: 8) {
                            RoundedRectangle(cornerRadius: 6)
                                .fill(Color(hex: c.hex))
                                .frame(width: 28, height: 28)
                                .overlay(RoundedRectangle(cornerRadius: 6).stroke(Color.white.opacity(0.2), lineWidth: 1))
                            VStack(alignment: .leading, spacing: 1) {
                                Text(c.hex)
                                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                                    .foregroundColor(.white)
                                Text("PMS \(c.pantone.number)")
                                    .font(.system(size: 9, design: .monospaced))
                                    .foregroundColor(.white.opacity(0.7))
                                Text("\(c.pct)% of image")
                                    .font(.system(size: 9))
                                    .foregroundColor(.white.opacity(0.65))
                            }
                            Spacer()
                            Text("copy")
                                .font(.system(size: 9))
                                .foregroundColor(.white.opacity(0.55))
                        }
                        .padding(.horizontal, 8)
                        .padding(.vertical, 6)
                        .background(Color(hex: "#C9829A"))
                        .cornerRadius(8)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color(hex: "#8B3050").opacity(0.3), lineWidth: 1))
                        .shadow(color: Color(hex: "#6E283C").opacity(0.2), radius: 2, x: 0, y: 2)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                
                Button("Upload another image") {
                    previewImage = nil
                    extractedColors = []
                }
                .font(.system(size: 10))
                .foregroundColor(Color(hex: "#7880A0"))
                .padding(.top, 4)
                
            } else {
                Button(action: { showImagePicker = true }) {
                    VStack(spacing: 8) {
                        Image(systemName: "photo")
                            .font(.system(size: 26))
                            .foregroundColor(Color(hex: "#7880A0"))
                        Text("Drop an image here\nor tap to browse")
                            .font(.system(size: 11))
                            .multilineTextAlignment(.center)
                            .foregroundColor(Color(hex: "#3D4A6A"))
                        Text("PNG, JPG, GIF, WEBP")
                            .font(.system(size: 10))
                            .foregroundColor(Color(hex: "#7880A0"))
                            .opacity(0.8)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 20)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color(hex: "#8B3050").opacity(0.3), style: StrokeStyle(lineWidth: 1.5, dash: [6, 4]))
                    )
                }
                .buttonStyle(PlainButtonStyle())
            }
        }
        .sheet(isPresented: $showImagePicker) {
            ImagePicker { image in
                previewImage = image
                extractedColors = extractColors(from: image)
            }
        }
    }
    
    func extractColors(from image: UIImage) -> [ExtractedColor] {
        guard let cgImage = image.cgImage else { return [] }
        let width = min(cgImage.width, 80)
        let height = min(cgImage.height, 80)
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        var pixelData = [UInt8](repeating: 0, count: width * height * 4)
        let context = CGContext(data: &pixelData, width: width, height: height,
                                bitsPerComponent: 8, bytesPerRow: width * 4,
                                space: colorSpace, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
        context?.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        
        var counts: [String: Int] = [:]
        var total = 0
        for i in stride(from: 0, to: pixelData.count, by: 4) {
            if pixelData[i+3] < 200 { continue }
            let r = Int(pixelData[i]) / 32 * 32
            let g = Int(pixelData[i+1]) / 32 * 32
            let b = Int(pixelData[i+2]) / 32 * 32
            let key = "\(min(r,255)),\(min(g,255)),\(min(b,255))"
            counts[key, default: 0] += 1
            total += 1
        }
        
        let sorted = counts.sorted { $0.value > $1.value }
        var result: [ExtractedColor] = []
        for (key, cnt) in sorted {
            if result.count >= 8 { break }
            let parts = key.split(separator: ",").compactMap { Int($0) }
            guard parts.count == 3 else { continue }
            let hex = String(format: "#%02X%02X%02X", parts[0], parts[1], parts[2])
            let tooClose = result.contains { existing in
                colorDistance(hex, existing.hex) < 55
            }
            if !tooClose {
                let pct = total > 0 ? Int(Double(cnt) / Double(total) * 100) : 0
                let match = closestPantone(hex: hex)
                result.append(ExtractedColor(hex: hex, pct: pct, pantone: match))
            }
        }
        return result
    }
}

// MARK: - Image Picker

struct ImagePicker: UIViewControllerRepresentable {
    let onPick: (UIImage) -> Void
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = .photoLibrary
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
    func makeCoordinator() -> Coordinator { Coordinator(onPick: onPick) }
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let onPick: (UIImage) -> Void
        init(onPick: @escaping (UIImage) -> Void) { self.onPick = onPick }
        func imagePickerController(_ picker: UIImagePickerController,
                                   didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let img = info[.originalImage] as? UIImage { onPick(img) }
            picker.dismiss(animated: true)
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true)
        }
    }
}

// MARK: - Toast

struct ToastView: View {
    let message: String
    var body: some View {
        Text(message)
            .font(.system(size: 11, design: .monospaced))
            .foregroundColor(Color(hex: "#F2EFE9"))
            .padding(.horizontal, 15)
            .padding(.vertical, 6)
            .background(Color(hex: "#2B3145"))
            .cornerRadius(20)
    }
}

// MARK: - Main App View

struct ChromaApp: View {
    @State private var primaryHue: Double = 200
    @State private var primarySat: Double = 0.75
    @State private var lightness: Double = 50
    @State private var mode: String = "complementary"
    @State private var history: [PaletteEntry] = []
    @State private var isDark: Bool = false
    @State private var toastMessage: String = ""
    @State private var showToast: Bool = false
    @State private var activeCombo: UUID? = nil
    
    let modes = ["none", "complementary", "analogous", "triadic"]
    let modeLabels = ["None", "Complementary", "Analogous", "Triadic"]
    
    var activePalette: [ColorSwatch] {
        var items: [ColorSwatch] = [
            ColorSwatch(hue: primaryHue, saturation: primarySat, lightness: lightness, label: "Base")
        ]
        for h in harmonyHues(base: primaryHue, mode: mode) {
            items.append(ColorSwatch(hue: h.hue, saturation: primarySat, lightness: lightness, label: h.label))
        }
        return items
    }
    
    var bgColor: Color { isDark ? Color(hex: "#18171A") : Color(hex: "#F2EFE9") }
    var sidebarColor: Color { isDark ? Color(hex: "#222126") : Color(hex: "#E8E4DC") }
    var borderColor: Color { isDark ? Color.white.opacity(0.08) : Color.black.opacity(0.09) }
    
    var body: some View {
        ZStack(alignment: .bottom) {
            HStack(spacing: 0) {
                // Left Sidebar
                leftSidebar
                    .frame(width: 200)
                    .background(sidebarColor)
                
                // Main Content
                mainContent
                
                // Right Sidebar
                rightSidebar
                    .frame(width: 210)
                    .background(sidebarColor)
            }
            .background(bgColor)
            .preferredColorScheme(isDark ? .dark : .light)
            
            // Toast
            if showToast {
                ToastView(message: toastMessage)
                    .padding(.bottom, 20)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .animation(.spring(response: 0.3), value: showToast)
            }
        }
        .ignoresSafeArea()
    }
    
    // MARK: Left Sidebar
    var leftSidebar: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                // Combos
                VStack(alignment: .leading, spacing: 9) {
                    Text("Color Combos")
                        .font(.system(size: 10, weight: .medium))
                        .tracking(1.3)
                        .textCase(.uppercase)
                        .foregroundColor(Color(hex: "#7880A0"))
                    
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 6) {
                        ForEach(combos) { combo in
                            ComboCard(combo: combo, isActive: activeCombo == combo.id, lightness: lightness) {
                                activeCombo = combo.id
                                primaryHue = combo.hues[0]
                                primarySat = 0.72
                                let spread = abs(combo.hues[0] - combo.hues[1])
                                mode = spread <= 60 ? "analogous" : "triadic"
                            }
                        }
                    }
                }
                .padding(13)
                
                Divider().background(borderColor)
                
                // History
                VStack(alignment: .leading, spacing: 9) {
                    HStack {
                        Text("History")
                            .font(.system(size: 10, weight: .medium))
                            .tracking(1.3)
                            .textCase(.uppercase)
                            .foregroundColor(Color(hex: "#7880A0"))
                        Spacer()
                        Button("Clear") { history = [] }
                            .font(.system(size: 9))
                            .tracking(0.6)
                            .textCase(.uppercase)
                            .foregroundColor(Color(hex: "#7880A0"))
                    }
                    
                    if history.isEmpty {
                        Text("No palettes saved yet")
                            .font(.system(size: 11))
                            .foregroundColor(Color(hex: "#7880A0"))
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding(.vertical, 10)
                    } else {
                        ForEach(history) { entry in
                            HistoryItemView(entry: entry) {
                                // Restore
                                if let first = entry.colors.first {
                                    primaryHue = first.hue
                                    primarySat = first.saturation
                                    lightness = first.lightness
                                    mode = entry.mode
                                }
                            } onDelete: {
                                history.removeAll { $0.id == entry.id }
                            }
                        }
                    }
                }
                .padding(13)
            }
        }
    }
    
    // MARK: Main Content
    var mainContent: some View {
        ScrollView {
            VStack(spacing: 13) {
                // Topbar
                HStack {
                    Text("CHROMA")
                        .font(.system(size: 11))
                        .tracking(1.8)
                        .foregroundColor(Color(hex: "#7880A0"))
                    Spacer()
                    Button(isDark ? "Light mode" : "Dark mode") { isDark.toggle() }
                        .font(.system(size: 11, weight: .medium))
                        .tracking(0.3)
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 6)
                        .background(Color(hex: "#C9829A"))
                        .cornerRadius(20)
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color(hex: "#8B3050").opacity(0.4), lineWidth: 1))
                        .shadow(color: Color(hex: "#6E283C").opacity(0.22), radius: 3, x: 0, y: 2)
                }
                .padding(.top, 4)
                
                // Wheel
                ColorWheelView(
                    size: 280,
                    lightness: lightness,
                    isDark: isDark,
                    primaryHue: $primaryHue,
                    primarySat: $primarySat,
                    mode: mode
                )
                
                // Mode buttons 2x2
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                    ForEach(Array(zip(modes, modeLabels)), id: \.0) { m, label in
                        ModeButton(title: label, isActive: mode == m) { mode = m }
                    }
                }
                .frame(maxWidth: 295)
                
                // Lightness
                VStack(spacing: 4) {
                    HStack {
                        Text("Lightness")
                            .font(.system(size: 10))
                            .tracking(0.6)
                            .textCase(.uppercase)
                            .foregroundColor(Color(hex: "#7880A0"))
                        Spacer()
                        Text("\(Int(lightness))%")
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundColor(Color(hex: "#3D4A6A"))
                    }
                    Slider(value: $lightness, in: 20...80, step: 1)
                        .accentColor(Color(hex: "#8B3050"))
                }
                .frame(maxWidth: 295)
                
                // Swatches
                SwatchStrip(swatches: activePalette) { hex in
                    copyToClipboard(hex)
                }
                
                // Pantone Panel
                PantonePanel(swatches: activePalette)
                    .frame(maxWidth: 320)
                
                // Save button
                Button("Save to history") {
                    let entry = PaletteEntry(mode: mode, colors: activePalette)
                    history.insert(entry, at: 0)
                    if history.count > 20 { history.removeLast() }
                    showToastMessage("Palette saved")
                }
                .font(.system(size: 11, weight: .medium))
                .tracking(0.3)
                .foregroundColor(.white)
                .padding(.horizontal, 18)
                .padding(.vertical, 6)
                .background(Color(hex: "#C9829A"))
                .cornerRadius(20)
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color(hex: "#8B3050").opacity(0.4), lineWidth: 1))
                .shadow(color: Color(hex: "#6E283C").opacity(0.22), radius: 3, x: 0, y: 2)
                
                Spacer(minLength: 20)
            }
            .padding(.horizontal, 14)
            .padding(.top, 18)
        }
    }
    
    // MARK: Right Sidebar
    var rightSidebar: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                Text("Extract from Image")
                    .font(.system(size: 10, weight: .medium))
                    .tracking(1.3)
                    .textCase(.uppercase)
                    .foregroundColor(Color(hex: "#7880A0"))
                
                ImageExtractorView { hex in copyToClipboard(hex) }
            }
            .padding(13)
        }
    }
    
    func copyToClipboard(_ hex: String) {
        UIPasteboard.general.string = hex
        showToastMessage("Copied \(hex)")
    }
    
    func showToastMessage(_ msg: String) {
        toastMessage = msg
        withAnimation { showToast = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
            withAnimation { showToast = false }
        }
    }
}

// MARK: - Entry Point

struct ContentView: View {
    var body: some View {
        ChromaApp()
    }
}

// MARK: - Color Extension

extension Color {
    init(hex: String) {
        let h = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        let r = Double(Int(h.prefix(2), radix: 16) ?? 0) / 255
        let g = Double(Int(h.dropFirst(2).prefix(2), radix: 16) ?? 0) / 255
        let b = Double(Int(h.dropFirst(4).prefix(2), radix: 16) ?? 0) / 255
        self.init(red: r, green: g, blue: b)
    }
}

// MARK: - Data

struct PantoneEntry { let name: String; let num: String; let hex: String }

let pantoneDB: [PantoneEntry] = [
    .init(name:"Yellow 012",num:"012 C",hex:"#FFD700"),
    .init(name:"Bright Orange",num:"151 C",hex:"#FF8200"),
    .init(name:"Red 032",num:"032 C",hex:"#EF3340"),
    .init(name:"Warm Red",num:"Warm Red C",hex:"#F9423A"),
    .init(name:"Rubine Red",num:"Rubine Red C",hex:"#CE0058"),
    .init(name:"Rhodamine Red",num:"Rhodamine Red C",hex:"#E10098"),
    .init(name:"Purple",num:"Purple C",hex:"#BB29BB"),
    .init(name:"Violet",num:"Violet C",hex:"#440099"),
    .init(name:"Reflex Blue",num:"Reflex Blue C",hex:"#001489"),
    .init(name:"Process Blue",num:"Process Blue C",hex:"#0085CA"),
    .init(name:"Green",num:"Green C",hex:"#00A651"),
    .init(name:"Black",num:"Black C",hex:"#2B2B2C"),
    .init(name:"Cool Gray 11",num:"Cool Gray 11 C",hex:"#53565A"),
    .init(name:"Cool Gray 5",num:"Cool Gray 5 C",hex:"#B1B3B3"),
    .init(name:"Warm Gray 11",num:"Warm Gray 11 C",hex:"#5B514B"),
    .init(name:"Warm Gray 3",num:"Warm Gray 3 C",hex:"#C6BAB1"),
    .init(name:"Bright Red",num:"185 C",hex:"#DA291C"),
    .init(name:"Coral Red",num:"179 C",hex:"#CF4520"),
    .init(name:"Orange 021",num:"021 C",hex:"#FE5000"),
    .init(name:"Dark Orange",num:"1665 C",hex:"#FC4C02"),
    .init(name:"Amber",num:"1235 C",hex:"#FFB81C"),
    .init(name:"Gold",num:"871 C",hex:"#8B6914"),
    .init(name:"Olive",num:"390 C",hex:"#8A9A24"),
    .init(name:"Lime",num:"375 C",hex:"#84BD00"),
    .init(name:"Emerald",num:"348 C",hex:"#00843D"),
    .init(name:"Teal",num:"3262 C",hex:"#00B0B9"),
    .init(name:"Sky Blue",num:"279 C",hex:"#418FDE"),
    .init(name:"Royal Blue",num:"286 C",hex:"#003DA5"),
    .init(name:"Navy",num:"281 C",hex:"#003087"),
    .init(name:"Midnight Blue",num:"539 C",hex:"#002A54"),
    .init(name:"Lavender",num:"265 C",hex:"#9063CD"),
    .init(name:"Lilac",num:"2563 C",hex:"#B57BCA"),
    .init(name:"Pink",num:"225 C",hex:"#E5007E"),
    .init(name:"Rose",num:"218 C",hex:"#DA4167"),
    .init(name:"Burgundy",num:"202 C",hex:"#9B2335"),
    .init(name:"Maroon",num:"505 C",hex:"#6F2C3F"),
    .init(name:"Cream",num:"9183 C",hex:"#F1E6D0"),
    .init(name:"Sand",num:"7501 C",hex:"#DDD0B3"),
    .init(name:"Tan",num:"7522 C",hex:"#C49A6C"),
    .init(name:"Brown",num:"4625 C",hex:"#5E2D20"),
    .init(name:"Sage",num:"5783 C",hex:"#8FA68E"),
    .init(name:"Mint",num:"3385 C",hex:"#2DCCA7"),
    .init(name:"Turquoise",num:"326 C",hex:"#00B388"),
    .init(name:"Aqua",num:"3255 C",hex:"#2BD4D0"),
    .init(name:"Cyan",num:"Cyan C",hex:"#00B5E2"),
    .init(name:"Steel Blue",num:"7700 C",hex:"#006E8C"),
    .init(name:"Cobalt",num:"293 C",hex:"#004B93"),
    .init(name:"Grape",num:"2685 C",hex:"#5B2182"),
    .init(name:"Plum",num:"5185 C",hex:"#7B3F5E"),
    .init(name:"Fuchsia",num:"812 C",hex:"#FF3EB5"),
    .init(name:"Blush",num:"705 C",hex:"#F4B9CB"),
    .init(name:"Peach",num:"488 C",hex:"#EDB98A"),
    .init(name:"Apricot",num:"1565 C",hex:"#F79663"),
    .init(name:"Tangerine",num:"1575 C",hex:"#FC7A1E"),
    .init(name:"Mustard",num:"1245 C",hex:"#D4930C"),
    .init(name:"Chartreuse",num:"381 C",hex:"#B5CC18"),
    .init(name:"Apple Green",num:"368 C",hex:"#4EAE34"),
    .init(name:"Forest Green",num:"357 C",hex:"#2D6A4F"),
    .init(name:"Seafoam",num:"3375 C",hex:"#4CAF82"),
    .init(name:"Jade",num:"3278 C",hex:"#00966C"),
    .init(name:"Denim",num:"7686 C",hex:"#3A5FA0"),
    .init(name:"Indigo",num:"2745 C",hex:"#2E2E8B"),
    .init(name:"Cerulean",num:"7702 C",hex:"#007AA5"),
    .init(name:"Slate",num:"7544 C",hex:"#5B7FA6"),
    .init(name:"Stone",num:"7530 C",hex:"#A08C7A"),
    .init(name:"Terracotta",num:"490 C",hex:"#C1440E"),
    .init(name:"Brick",num:"1685 C",hex:"#C05131"),
    .init(name:"Crimson",num:"200 C",hex:"#BA0C2F"),
    .init(name:"Scarlet",num:"1797 C",hex:"#D22630"),
    .init(name:"Rust",num:"1605 C",hex:"#B7410E"),
    .init(name:"Sienna",num:"1615 C",hex:"#A0522D"),
    .init(name:"Off White",num:"9001 C",hex:"#EDEAE0"),
    .init(name:"Powder Blue",num:"278 C",hex:"#7BA7BC"),
    .init(name:"Umber",num:"4645 C",hex:"#7B5B41"),
    .init(name:"Pumpkin",num:"1595 C",hex:"#E35D2A"),
]

let combos: [ComboPreset] = [
    .init(name:"Sunset", desc:"Warm amber & rose", hues:[25,340,55]),
    .init(name:"Ocean",  desc:"Deep aqua tones",   hues:[195,215,175]),
    .init(name:"Forest", desc:"Rich earthy greens", hues:[125,85,155]),
    .init(name:"Berry",  desc:"Plum & violet",      hues:[280,310,250]),
    .init(name:"Ember",  desc:"Red-orange heat",    hues:[12,35,355]),
    .init(name:"Storm",  desc:"Blue-grey contrast", hues:[215,240,190]),
    .init(name:"Blossom",desc:"Soft pink & peach",  hues:[340,15,310]),
    .init(name:"Harvest",desc:"Warm ochre & rust",  hues:[38,18,58]),
]

